#include "exception.h"


void Cexception::message(std::ostream &os,MyString & fn)
{
	switch(err_code)
	{
		case ERR_OF:
			os<<"Eroare deschidere fisier "<<fn<<"!\n";
			break;
		case ERR_EL:
			os<<"Empty DataBase ! \n";
			break;
		case ERR_MNSWT:
			os<<"No. of SWT reached !\n";
			break;
		case ERR_MNSWB:
			os<<"No. of SWB reached !\n";
	}
}
