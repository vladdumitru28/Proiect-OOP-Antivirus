#ifndef SMANAGER_H
#define SMANAGER_H
#include "ScanWorkerBin.h"
#include "ScanWorkerTxt.h"

class ScanManager{
private:
	const int m_nosw;
	static ScanManager *mp_instance;
	MyList<ScanWorker*> m_swlist;
	ScanManager(int n)
		:m_nosw(n), m_swlist(n)
	{
		ScanWorker*x=NULL;
		m_swlist.listset(x);
	}
	~ScanManager();
	
public:
	static ScanManager& get_instance(int );
	static void destroy_instance();
	void scan(MyString & , DataBase& , int p=100);
	int existfreeSW(sw_tip);
	void sumar();
};



#endif