#ifndef DATAB_H
#define DATAB_H
#include "exception.h"
#include "MyList.h"

class DataBase{
private:
	MyList<MyString> m_txt;
	MyList<MyString> m_bin;
public:
	DataBase()
		:m_txt(), m_bin() {}
	DataBase(const MyList<MyString> &x , const MyList<MyString> &y)
		:m_txt(x), m_bin(y) {}
	DataBase( MyString & );
	~DataBase();
	bool operator == ( DataBase&);
	void update(MyString&);
	MyList<MyString> & getdbTxt()  {return m_txt;}
	MyList<MyString> & getbdBin()  {return m_bin;}
	void print();
};



#endif