#include "ScanManager.h"

ScanManager::~ScanManager()
{
	for(int i=0;i<=m_swlist.get_it();i++)
	{
		delete m_swlist.getcontent(i);
	}


}
void ScanManager::destroy_instance()
{
	if(mp_instance==NULL)
		return;
	delete mp_instance;
	mp_instance=NULL;
}
ScanManager& ScanManager::get_instance(int swno)
{
	if(mp_instance==NULL)
		mp_instance=new ScanManager(swno);
	return *mp_instance;
}
void ScanManager::scan(MyString &fl, DataBase &db, int p)
{
	for(int i=0;i<=m_swlist.get_it();i++)
		m_swlist.getcontent(i)->setocc(0);
	try
	{
	if(db.getbdBin().get_it()==-1 && db.getdbTxt().get_it()==-1)
		throw new Cexception(ERR_EL);
	while(!fl.get_eos())
	{
		MyString *temp,*temp1;
		temp=fl.mystrtok(" ");
		temp1=temp->mystrtok(".");
		delete temp1;
		temp1=temp->mystrtok(".");
	try
	{
		if(*temp1==MyString("txt"))
		{
			int i=this->existfreeSW(SWTxt);
			if(i!=-1)//tratare exceptie
			{
				if(m_swlist.getcontent(i)==NULL)
				{
					ScanWorker *aux=new ScanWorkerTxt;
					m_swlist.push(aux);
				}
				m_swlist.getcontent(i)->scan(*temp,db,p);
			}
			else
				throw new Cexception(ERR_MNSWT);
		}
		else
		{	
			int i=this->existfreeSW(SWBin);
			if(i!=-1)//tratare exceptie
			{
				if(m_swlist.getcontent(i)==NULL)
				{
					ScanWorker *aux=new ScanWorkerBin;
					m_swlist.push(aux);
				}
				m_swlist.getcontent(i)->scan(*temp,db,p);
			}
			else
				throw new Cexception(ERR_MNSWB);
		}
	}//////////////////////
	catch(Cexception *ex)
	{
		ex->message(ScanWorker::m_rfile,MyString(" "));
		if(ex->geterrcode()==ERR_MNSWB)
		{
			int i=this->existfreeSW(SWTxt);
			if(i==-1)
			{
				ScanWorker::m_rfile<<"Nothing can do !\n"<<"Scanare incheiata!!\n\n";
				delete ex;
				delete temp;
				delete temp1;
				return;
			}
			else
			{
				delete m_swlist.getcontent(i);
				m_swlist.getcontent(i)= new ScanWorkerBin;
				m_swlist.getcontent(i)->scan(*temp,db,p);
			}

		}
		else
		{
			int i=this->existfreeSW(SWBin);
			if(i==-1)
			{
				ScanWorker::m_rfile<<"Nothing can do !\n"<<"Scanare incheiata !!\n\n";
				delete ex;
				delete temp;
				delete temp1;
				return;
			}
			else
			{
				delete m_swlist.getcontent(i);
				m_swlist.getcontent(i)= new ScanWorkerTxt;
				m_swlist.getcontent(i)->scan(*temp,db,p);
			}
		}
		delete ex;


	}

		delete temp1;
		delete temp;
	}
	}
	catch(Cexception *ex)
	{
		ex->message(ScanWorker::m_rfile,MyString(" "));
		delete ex;
	}

	
	ScanWorker::m_rfile<<"Scanare incheiata !!\n\n";

}
int ScanManager::existfreeSW(sw_tip swt)
{
	for(int i=0;i<=m_swlist.get_it();i++)
	{
		ScanWorker * temp = m_swlist.getcontent(i);
		if(temp->gettip()==swt && temp->is_occ()==0)
			return i;
	}
	if(m_swlist.eol())
		return -1;
	else
		return m_swlist.get_it()+1;

}
void ScanManager::sumar()
{
	ScanWorker::m_rfile<<"Sumar scanare:\n\tNumar SW folositi:"<<ScanWorker::m_counter;
	ScanWorker::m_rfile<<"\n\tNumar sisiere scanare:"<<ScanWorker::m_scanedF;
}
