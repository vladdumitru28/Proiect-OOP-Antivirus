#include "ScanWorkerTxt.h"

void ScanWorkerTxt::scan(MyString &fn,DataBase &db,int p)
{
	
	int nr_cont=0;
	try
	{
	ifstream ffs(fn.get_content());
	if(!ffs.is_open())
		throw new Cexception(ERR_OF);
	
	m_occ=1;
	for(int i=0;i<=db.getdbTxt().get_it();i++)
	{
		MyString* ms;
		ms=(db.getdbTxt().getcontent(i))%p;
		while(!ffs.eof())
		{
			MyString temp;
			ffs>>temp;
			//if(temp^ms)
			nr_cont+=temp^*ms;
		}
		delete ms;
		ffs.seekg(0,ffs.beg);
	}
	ffs.close();
	this->raporte(nr_cont,fn);
	}
	catch(Cexception *er)
	{
		er->message(m_rfile,fn);
		delete er;
	}


}
