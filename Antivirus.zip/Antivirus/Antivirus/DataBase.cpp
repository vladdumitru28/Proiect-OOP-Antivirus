#include "DataBase.h"


DataBase::DataBase(MyString &x)
{
	this->update(x);
}
DataBase::~DataBase()
{

}
bool DataBase::operator==(  DataBase& x)
{
	for(int i=0;i<=m_txt.get_it();i++)
		if(x.m_txt.search(this->m_txt.getcontent(i))==-1)
			return 0;

	for(int i=0;i<=m_bin.get_it();i++)
		if(x.m_bin.search(this->m_bin.getcontent(i))==-1)
			return 0;
	return 1;
}
void DataBase::update(MyString& x)
{
	MyString *aux;
	while(!(x.get_eos()))
	{
		aux=x.mystrtok(" ");
		if(aux->findchr("."))
			m_bin.push(*aux);
		else
			m_txt.push(*aux);
		delete aux;
	}

}
void DataBase::print()
{
	cout<<"Cuvinte malitioase:"<<endl;
	for(int i=0;i<=m_txt.get_it();i++)
		cout<<m_txt.getcontent(i).get_content()<<endl;
	cout<<"Fisiere cu secvente malitioase: "<<endl;
	for(int i=0;i<=m_bin.get_it();i++)
		cout<<m_bin.getcontent(i).get_content()<<endl;
	cout<<endl;
}

