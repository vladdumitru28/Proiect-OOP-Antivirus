#ifndef MYLIST_H
#define MYLIST_H
#define max_dim_list 100
 
template <class T>
class MyList{
private:
	T* m_content;
	int m_maxdim;
	int m_it;
public:
	int get_maxdim() const {return m_maxdim;}
	int get_it() const {return m_it;}
	T* getcontent_ptr() const {return m_content;}
	MyList();
	MyList(int);
	MyList(const MyList<T> &);
	~MyList();
	void push(T&);
	void pop();
	void listset(T&);
	int search(T&);
	bool eol();
	T& getcontent (int);



};


template <class T>
MyList<T>::MyList()
{
	m_maxdim=max_dim_list;
	m_it=-1;
	m_content=new T[m_maxdim];
}
template <class T>
MyList<T>::MyList(int x)
{
	m_maxdim=x;
	m_it=-1;
	m_content=new T[m_maxdim];
}
template <class T>
MyList<T>::MyList(const MyList<T> & x)
{
	m_maxdim=x.get_maxdim();
	m_it=x.get_it();
	m_content=new T[m_maxdim];
	for(int i=0;i<m_maxdim;i++)
		m_content[i]=x.getcontent_ptr()[i];
}
template <class T>
MyList<T>::~MyList()
{
	delete [] m_content;
}

template <class T>
void MyList<T>::push(T& x)
{
	if(!(this->eol()))
		m_content[++m_it]=x;
}
template <class T>
int MyList<T>::search(T& x)
{
	for(int i=0;i<=m_it;i++)
	{
		if(m_content[i]==x)
			return i;
	}
	return -1;
}

template <class T>
void MyList<T>::pop()
{
	if(m_it==-1)
		return;
	m_it--;
}

template <class T>
bool MyList<T>::eol()
{
	if(m_it==m_maxdim-1)
		return 1;
	return 0;
}

template <class T>
T& MyList<T>::getcontent(int i) 
{
	
	return m_content[i];
}

template<class T>
void MyList<T>::listset(T& x)
{
	for(int i=0;i<m_maxdim;i++)
		m_content[i]=x;
}



#endif
