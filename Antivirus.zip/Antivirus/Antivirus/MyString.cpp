#include "MyString.h"


MyString::MyString(const char *x)
{
	m_content=new char[strlen(x)+1];
	strcpy(m_content,x);
	m_cp=0;
	m_eos=0;
}
MyString::MyString(const MyString& x)
{
	m_content=new char[strlen(x.get_content())+1];
	strcpy(m_content,x.get_content());
	m_cp=x.get_cp();
	m_eos=x.get_eos();
}
void MyString::set_content(const char *x)
{
	delete [] m_content;
	m_content=new char[strlen(x)+1];
	strcpy(m_content,x);
}
void MyString::operator=(const MyString& x)
{
	this->set_content(x.get_content());
	
}
MyString* MyString:: mystrtok(const char* x)
{
	MyString *temp;
	char *aux1,*aux2;
	aux1=strpbrk((this->m_content)+this->m_cp,x);
	if(aux1!=NULL)
	{
		aux2=new char[aux1-(m_content+m_cp)+2];
		strncpy(aux2,(this->m_content)+this->m_cp,aux1-m_content-m_cp);
		aux2[aux1-m_content-m_cp]=NULL;
		m_cp=aux1-m_content+1;
	}
	else
	{
		aux2=new char[strlen(m_content)-m_cp+1];
		strncpy(aux2, m_content+m_cp, strlen(m_content)-m_cp);
		aux2[strlen(m_content)-m_cp]=NULL;
		m_eos=1;
		
	}
	temp=new MyString(aux2);
	delete [] aux2;
	return temp;
}
bool MyString::findchr(const char *x)
{
	char *aux=strpbrk(this->m_content,x);
	if(aux!=NULL)
		return 1;
	return 0;
}
bool MyString::operator==(const MyString& x)
{
	if(strcmp(this->m_content,x.get_content())==0)
		return 1;
	return 0;
}
bool MyString::operator !=(const MyString &x)
{
	if(strcmp(this->m_content,x.m_content)==0)
		return 0;
	return 1;
}

ostream&  operator<<(ostream& os, MyString & x)
{
	os<<x.m_content;
	return os;
}

istream& operator>>(istream &is, MyString & x)
{
	delete [] x.m_content;
	x.m_content=new char [100];
	is>>x.m_content;
	return is;
}

int MyString::operator^(const MyString& sstr)
{
	char *aux=strstr(m_content,sstr.m_content);
	int nr=0;
	while(aux!=NULL)
	{
		nr++;
		aux=strstr(aux+1,sstr.m_content);
	}
	return nr;
}

MyString* MyString::operator%(int p)
{
	
	int nr=((strlen(this->m_content)*p)/100)+1;
	char *aux=new char [nr];
	strncpy(aux,this->m_content,nr-1);
	aux[nr-1]=NULL;
	MyString *temp=new MyString(aux);
	delete [] aux;
	return temp;
	
}
