#ifndef SWTXT_H
#define SWTXT_H
#include "ScanWorker.h"

class ScanWorkerTxt : public ScanWorker
{
public:
	ScanWorkerTxt()
		:ScanWorker(SWTxt){}
	~ScanWorkerTxt(){}
	void scan(MyString &, DataBase &,int p);
};






#endif