#include "ScanManager.h"
//#include "vld.h"
int ScanWorker::m_counter=0;
ofstream ScanWorker::m_rfile("reportFile.txt");
ScanManager * ScanManager::mp_instance=NULL;
int ScanWorker::m_scanedF=0;
using namespace std;
void main()
{
	
	MyString a("virus malware.bin malware1.bin virus2 malware2.bin malware3.bin");
	MyString b("Review.pdf ffs.txt isnexist.h");
	DataBase db(a);
	DataBase for_test;
	db.print();
	ScanManager & SM=ScanManager::get_instance(2);
	//pt. a testa in modul "strict", functia scan trebuie parametrizata
	//cu un "int" care semnifica procentul, altfel nu se specifica al
	// 3-lea parametru.
	SM.scan(b,for_test,40);//testare exceptie baza de date goala
	SM.scan(b,db,40);//testare program
	MyString c("ffs.txt ffs.txt");//testare depasire nr.SW
	SM.scan(c,db,40);
	SM.sumar();
	SM.destroy_instance();
	ScanWorker::m_rfile.close();
	//testare up_to_date in raport cu alta baza de date
	MyString d("virus2 virus malware.bin malware2.bin malware1.bin malware3.bin");
	DataBase db_for_test(d);
	db_for_test.print();
	if(db_for_test==db)
		cout<<"up-to-date\n\n";
	//testare update
	db.update(MyString("ionel in4.pdf ghita in5.docx"));
	db.print();

	
}
