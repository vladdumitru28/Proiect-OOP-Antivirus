#ifndef EXCC_H
#define EXCC_H
#define ERR_MNSWB 100
#define ERR_MNSWT 101
#define ERR_OF 102
#define ERR_EL 103

#include "MyString.h"

class Cexception{

private:
	int err_code;
public:
	Cexception(int x)
		:err_code(x){}
	~Cexception(){}
	int geterrcode(){return err_code;}
	void message(std::ostream &,MyString&);
	
};


#endif