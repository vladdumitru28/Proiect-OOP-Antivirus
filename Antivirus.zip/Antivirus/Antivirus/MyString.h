#ifndef MYSTRING_H
#define MYSTRING_H

#include <iostream>
using namespace std;
class MyString{
private:
	char *m_content;
	int m_cp;//check point
	bool m_eos;
public:
	MyString()
		:m_content(NULL),m_cp(0),m_eos(0){}
	MyString(const char*);
	MyString(const MyString&);
	~MyString(){
		//std::cout<<"DESTRUCTOR"<<m_content<<"\n";
		delete [] m_content;}
	char *get_content() const {return m_content;}
	int get_cp() const {return m_cp;}
	bool get_eos() const{return m_eos;}
	void set_content(const char *);
	void operator=(const MyString&);
	bool operator==(const MyString&);
	bool operator!=(const MyString&);
	MyString *mystrtok(const char * );
	int operator ^ (const MyString& sstr);
	MyString* operator%(int p);
	bool findchr(const char *);
	friend ostream& operator << (ostream &, MyString&);
	friend istream& operator >> (istream &, MyString&);


};



#endif