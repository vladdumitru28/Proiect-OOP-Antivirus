#ifndef SWORKER_H
#define SWORKER_H
#include "DataBase.h"
#include <fstream>

typedef enum sw_tip{
					SWTxt,
					SWBin};
class ScanWorker{	
protected:
	int m_id;
	sw_tip m_tip;
	bool m_occ;
public:
	ScanWorker(sw_tip y)
		:m_id(m_counter) , m_tip(y) , m_occ(0){m_counter++;}
	~ScanWorker(){}
	virtual void scan(MyString &, DataBase &, int p) = 0;
	void raporte(int , MyString&);
	sw_tip gettip(){return m_tip;}
	void setocc(bool i){m_occ=i;}
	bool is_occ(){return m_occ;}
	static int m_counter;
	static int m_scanedF;
	static ofstream m_rfile;
	

};








#endif