#ifndef SWBIN_H
#define SWBIN_H

#include "ScanWorker.h"


class ScanWorkerBin : public ScanWorker
{
public:
	ScanWorkerBin()
		:ScanWorker(SWBin){}
	~ScanWorkerBin(){}
	void scan(MyString &,DataBase &, int p);

};




#endif