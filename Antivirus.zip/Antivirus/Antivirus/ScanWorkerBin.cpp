#include "ScanWorkerBin.h"

void ScanWorker::raporte(int ni, MyString &filen)
{
	m_rfile<<filen<<"||wID:"<<m_id<<"||no. of infection: "<<ni<<endl;
	m_occ=1;
	m_scanedF++;
}


void ScanWorkerBin::scan(MyString &fn, DataBase& db,int p)
{
	
	ifstream ffs,fms;
	int nr_cont=0;
	try
	{
	ffs.open(fn.get_content(),ifstream::binary);
	if(!ffs.is_open())
		throw new Cexception (ERR_OF);
	m_occ=1;
	char *ms;
	MyString temp2;
	for(int i=0;i<=db.getbdBin().get_it();i++)
	{
		temp2=db.getbdBin().getcontent(i);
		fms.open(temp2.get_content(),ios::binary);
		fms.seekg(0,fms.end);
		int nr=((fms.tellg())*p)/100;
		fms.seekg(0,fms.beg);
		ms=new char [nr];
		fms.read(ms,nr);
		fms.close();
		char c;
		while(ffs.get(c))
		{
			int cp=ffs.tellg();
			if(c==ms[0])
			{
				bool ok=1;
				char *buff=new char[nr];
				ffs.read(buff,nr-1);
				for(int j=0;j<nr-1;j++)
					if(buff[j]!=ms[j+1])
					{ok=0;break;}
				if(ok==1)
					nr_cont++;
				else
					ffs.seekg(cp,ffs.beg);
				delete [] buff;
			}
		}
		ffs.seekg(0,ffs.beg);
		delete [] ms;
	}
	ffs.close();
	this->raporte(nr_cont,fn);

	}
	catch(Cexception *ex)
	{
		ex->message(m_rfile,fn);
		delete ex;

	}
	
}
